ax = districts2.plot(column='n_bike_stations_by_area',
                    figsize=(15, 6))
ax.set_axis_off()