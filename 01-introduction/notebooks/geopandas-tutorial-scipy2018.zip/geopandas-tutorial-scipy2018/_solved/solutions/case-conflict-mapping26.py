mines_kahuzi = data_utm[data_utm.within(kahuzi)]
mines_kahuzi