# convert the above in a DataFrame with two columns
counts = counts.reset_index(name='n_bike_stations')
counts.head()