function d3_source(d) {
  return d.source;
}
